import React from 'react';
import IntlMessages from '@crema/utility/IntlMessages';
import AppAnimateGroup from '@crema/core/AppAnimateGroup';
import '../index.style.scss';
import AppPageMetadata from '@crema/core/AppPageMetadata';
import { ReactComponent as Logo } from '../../../assets/icon/401.svg';
import Button from 'devextreme-react/button';
// import Button from 'react-bootstrap/Button';
import '../../errorPages/Error401/index.style.scss'
import DataGrid, {
  Column,
  Pager,
  Paging,
  SearchPanel,
  Sorting,
  ColumnChooser,
  FilterRow,
  Toolbar
} from 'devextreme-react/data-grid';
// import 'devextreme/dist/css/dx.generic.ATD-DataGrid-md - Copy1.css';
import DropDownButton from 'devextreme-react/drop-down-button';
import style from '../Error401/index.style.scss';
import { Dropdown, DropdownButton } from 'react-bootstrap';
import { Search } from 'react-bootstrap-icons';

// import { Paper } from '@material-ui/core';



const actions = [
  { id: 1, text: "Name" },
  { id: 2, text: "FINS Number" },
  { id: 3, text: "File Number(A#)" },
  { id: 4, text: "State Number" },
  { id: 5, text: "FBI Number" },
  { id: 6, text: "Passport Number" },
  { id: 7, text: "Date of Birth" },
  { id: 8, text: "Country of Birth" },

];
const dropDownOptions = {
  height: 150,
  width: 130
};

export const NonCitizenDetails = [
  {
    file: '7462027253',
    name: 'Hussain',
    fins: '4729272',
    state: 'Alaska',
    fbi: '7465464874',
    monitoring: 'Phone App',
    dateofentry: '08/09/2022',
    cob: 'India'
  },
  {
    file: '37492649027',
    name: 'Ruhi',
    fins: '3749294203',
    state: 'Alabama',
    fbi: '7465464874',
    monitoring: 'Phone App',
    dateofentry: '08/09/2022',
    cob: 'U.S'
  },
  {
    file: '4873483846',
    name: 'Thomas',
    fins: '3739272',
    state: 'California',
    fbi: '7465464874',
    monitoring: 'Phone App',
    dateofentry: '08/09/2022',
    cob: 'China'
  },
  {
    file: '3739262003',
    name: 'Richard',
    fins: '2345678',
    state: 'Delaware',
    fbi: '7465464874',
    monitoring: 'Phone App',
    dateofentry: '08/09/2022',
    cob: 'Indonesia'
  },
  {
    file: '37291539320',
    name: 'Charles',
    fins: '63825218',
    state: 'Idaho',
    fbi: '7465464874',
    monitoring: 'Phone App',
    dateofentry: '08/09/2022',
    cob: 'India'
  },
  {
    file: '1234567879',
    name: 'Christopher',
    fins: '2345678',
    state: '45673892',
    fbi: '7465464874',
    monitoring: 'Phone App',
    dateofentry: '08/09/2022',
    cob: 'Brazil'
  },
  {
    file: '4372926628',
    name: 'Matthew',
    fins: '234572678',
    state: 'Idaho',
    fbi: '7465464874',
    monitoring: 'Phone App',
    dateofentry: '08/09/2022',
    cob: 'Bangladesh'
  },
  {
    file: '2748392629',
    name: 'Mark',
    fins: '2346385678',
    state: 'Oregon',
    fbi: '7465464874',
    monitoring: 'Phone App',
    dateofentry: '08/09/2022',
    cob: 'India'
  },
  {
    file: '63726528276',
    name: 'Kevin',
    fins: '2345743678',
    state: 'Virginia',
    fbi: '7465464874',
    monitoring: 'Phone App',
    dateofentry: '08/09/2022',
    cob: 'Belgium'
  },
  {
    file: '1234567879',
    name: 'Timothy',
    fins: '2345678',
    state: 'Virginia',
    fbi: '7465464874',
    monitoring: 'Phone App',
    dateofentry: '08/09/2022',
    cob: 'Afganisthan'
  },
  {
    file: '083567879',
    name: 'Jonathan',
    fins: '234335678',
    state: 'South Dakota	',
    fbi: '7465464874',
    monitoring: 'Phone App',
    dateofentry: '06/03/2020',
    cob: 'Cuba'
  },
  {
    file: '8931237879',
    name: 'Gary',
    fins: '362920',
    state: 'Oklahoma',
    fbi: '7465464874',
    monitoring: 'Phone App',
    dateofentry: '07/09/2021',
    cob: 'Egypt'
  },
];


const NonCitizen = () => {

  return (
    // <Paper>
    //   <Box>
    <div >
      <div className='col-md-9 main-header'>
        <p>NON-CITIZEN LIST SEARCH</p>
      </div>

      {/* <Button variant="danger">Danger</Button>{' '} */}

      <div className='row'>
        <div className='col-md-12'>
          <div className='display-flex'>
            <DropDownButton
              className='me-3'
              text="Search By"
              items={actions}
              keyExpr="id"
              displayExpr="text"
              type='lightGray'
              dropDownOptions={dropDownOptions}
            />
            <Button
              className='me-3 btn-darkGray'
              text="Search"
            />
            <Button
              className='me-3 btn-Gray'
              text="Reset"
            />
            <Button className='float-end btn-darkGray'
              text="Advanced Search"
            />
          </div>
        </div>
      </div>
      <div className='col-md-9'>
        <h6 className='display-inline search-header'>
          SEARCH RESULTS :
          <span className='search-profile'>
            1150 PROFILES
          </span>

        </h6>
      </div>

      {/* <div className='btn-dark'>
  sai 
</div> */}
      <DataGrid
        className='card-body'
        dataSource={NonCitizenDetails}
        keyExpr={'file'}
        allowColumnReordering={true}>

        <Column
          dataField={'file'}
          caption={'File#(A#)'}
        // allowSorting={false}
        // allowFiltering={false}
        // allowGrouping={false}
        // allowReordering={false}
        // visible={false}
        />
        <Column dataField={'name'} caption={'NAME'} />
        <Column dataField={'fins'} caption={'FINS#'} />
        <Column dataField={'state'} caption={'STATE#'} />
        <Column dataField={'fbi'} caption={'FBI#'}/>
        <Column dataField={'monitoring'} caption={'MONITORING'} />
        <Column dataField={'dateofentry'} caption={'DATE OF ENTRY'} />
        <Column dataField={'cob'} caption={'COB'} />
        <FilterRow visible={true} />
        <ColumnChooser enabled={true} mode='select' />
        <SearchPanel
          className='float-start'
          visible={true}
          width={240}
          placeholder="Search..."
        />
        <Pager allowedPageSizes={[5, 10, 20]} showPageSizeSelector={true} showNavigationButtons={true} />
        <Paging defaultPageSize={5} />

      </DataGrid>
    </div>

    //    </Box>
    // </Paper>

  );
};

export default NonCitizen;
